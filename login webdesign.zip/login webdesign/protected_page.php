<?php
session_start();
// Check if the user is authenticated (you can use more secure methods for this)
if (!isset($_SESSION["authenticated"]) || $_SESSION["authenticated"] !== true) {
    header("Location: login.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Protected Page</title>
</head>
<body>
    <h1>Welcome to the protected page!</h1>
    <!-- Your content for authenticated users goes here -->
</body>
</html>