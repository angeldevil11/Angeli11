<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user input
    $username = $_POST["username"];
    $password = $_POST["password"];
    
    // Replace these with your actual credentials
    $valid_username = "your_username";
    $valid_password = "your_password";
    
    // Check if the input matches the valid credentials
    if ($username === $valid_username && $password === $valid_password) {
        // Redirect to a protected page after successful login
        header("Location: protected_page.php");
        exit;
    } else {
        echo "Invalid username or password. Please try again.";
    }
}
?>